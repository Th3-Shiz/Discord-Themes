This font is a demo version font and does not contain all glyphs, and may only be used for personal use.
for the full version and license you can buy it at https://creativemarket.com/Ef_Studio or https://fontbundles.net/ef-studio

If you need an extended license or corporate license, please contact us at
efstudio2@gmail.com

Thank you

Ef Studio